<?php

exit("Can I tell you a story?");

?>